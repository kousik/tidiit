<?php
$config['mobileBoxContents']=array('1'=>'Handset','2'=>'Charger','3'=>'USB Cable','4'=>'User Manual','5'=>'Warranty Card');
$config['mobileColor']=array('1'=>'Red','2'=>'Blue','3'=>'Gray','4'=>'Orrange');
$config['mobileDisplayResolution']=array('1'=>'320 X 480','2'=>'360 X 640','3'=>'720 x 1280');
$config['mobileConnectivity']=array('1'=>'GSM','2'=>'CDMA','3'=>'3G/WCDMA','4'=>'4G/LTE');
$config['mobileOS']=array('1'=>'Android','2'=>'IOS','3'=>'Windos','4'=>'Blackbery');
$config['mobileProcessorCores']=array('1'=>'Duo Core');
$config['mobileProcessorBrand']=array('1'=>'Asus','2'=>'Intel');
$config['mobileBatteryType']=array('1'=>'lean','2'=>'Intel');
$config['priceRangeSettings']=array(
  'mobile'=>array('start'=>5,'consistencyNo'=>5,'end'=>5000),  
  'laptop'=>array('start'=>1,'consistencyNo'=>2,'end'=>500),  
  'desktop'=>array('start'=>1,'consistencyNo'=>2,'end'=>500),  
);
$config['lengthClass']=array('1'=>'Centimeter','2'=>'Millimeter','3'=>'Inch');
$config['weightClass']=array('1'=>'Kilogram','2'=>'Gram','3'=>'Pound','4'=>'Quintal');
