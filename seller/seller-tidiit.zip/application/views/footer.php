<script src="<?php echo SiteJSURL;?>moment.min.js"></script>
    <!-- MetisMenu -->
    <script src="<?php echo SiteJSURL;?>metisMenu.min.js"></script>

    <!-- Screenfull -->
    <script src="<?php echo SiteJSURL;?>screenfull.min.js"></script>

    <!-- Metis core scripts -->
    <script src="<?php echo SiteJSURL;?>core.min.js"></script>

    <!-- Metis demo scripts -->
    <script src="<?php echo SiteJSURL;?>app.js"></script>
<footer class="Footer bg-dark dker">
      <p>Seller Admin Section</p>
    </footer><!-- /#footer -->
    
<div id="dialog-confirm" title="Remove product from cart" style="display: none;">
        <p><span id="dialog-confirm-message-text"></span></p>
    </div>