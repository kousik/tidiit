<?php
class Product extends MY_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('Product_model');
		$this->load->model('Category_model');
                parse_str($_SERVER['QUERY_STRING'],$_GET);
            $this->db->cache_off();
	}

	public function index(){
		redirect(base_url().'admin');
	}

	public function viewlist(){
            $data=$this->_get_logedin_template();
            /*$data['ckeditor'] = array(
                    //ID of the textarea that will be replaced
                    'id' 	=> 	'Description',
                    'path'	=>	$this->config->item('SiteJSURL').'ckeditor',
                    'judhipath'	=>	$this->config->item('SiteJSURL'),
                    //Optionnal values
                    'config' => array(
                            'toolbar' 	=> 	"Full", 	//Using the Full toolbar
                            'width' 	=> 	"90%",	//Setting a custom width
                            'height' 	=> 	'250px',	//Setting a custom height
                    )
            );
            $menuArr=array();
            $TopCategoryData=$this->Category_model->get_top_category_for_product_list();
            //$AllButtomCategoryData=$this->Category_model->buttom_category_for_product_list();
            foreach($TopCategoryData as $k){
                $SubCateory=$this->Category_model->get_subcategory_by_category_id($k->categoryId);
                if(count($SubCateory)>0){
                    foreach($SubCateory as $kk => $vv){
                        $menuArr[$vv->categoryId]=$k->categoryName.' -> '.$vv->categoryName;
                        $ThirdCateory=$this->Category_model->get_subcategory_by_category_id($vv->categoryId);
                        if(count($ThirdCateory)>0){
                            foreach($ThirdCateory AS $k3 => $v3){
                                // now going for 4rath
                                $menuArr[$v3->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName;
                                $FourthCateory=$this->Category_model->get_subcategory_by_category_id($v3->categoryId);
                                if(count($FourthCateory)>0){ //print_r($v3);die;
                                    foreach($FourthCateory AS $k4 => $v4){
                                        $menuArr[$v4->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName.' -> '.$v4->categoryName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $data['CategoryData']=$menuArr;
            $OldProductTags=$this->Product_model->get_all_tag();
            $OldProductTagsStr='';
            foreach($OldProductTags AS $k){
                if($OldProductTagsStr==''){
                    $OldProductTagsStr="'$k->name',";
                }else{
                    $OldProductTagsStr=$OldProductTagsStr."'$k->name',";          //'"'.$k->name.'",';
                    //echo $k->name.' == '.$OldProductTagsStr.'<br>';
                }
            }
            //echo $OldProductTagsStr;die;
            if(substr($OldProductTagsStr,-1)==','){
                $OldProductTagsStr=  substr($OldProductTagsStr, 0,-1);
            }
            $data['OldProductTagsStr']=$OldProductTagsStr;
            $per_page=50;
            $PaginationConfig=array(
                'base_url'=>base_url() . "admin/product/viewlist",
                'total_rows'=>$this->Product_model->get_admin_total(),
                'per_page'=>$per_page,
                'num_links'=>25,
                'uri_segment'=>4
                );
            $this->_my_pagination($PaginationConfig);
            //echo $this->uri->segment(4);die;

            $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
            //echo 'KK  '.$config['per_page'];die;
            if($page==0){
                $offcet=0;
            }else{
                $offcet=$per_page*($page-1);
            }
            $data['DataArr']=$this->Product_model->get_all_admin($per_page,$offcet);


            $data["links"] = $this->pagination->create_links();
             * 
             */
            $this->load->view('product_list',$data);
	}
        
        function add_product($productPageType=""){
            $this->config->load('product');
            $data=$this->_get_logedin_template();
            $menuArr=array();
            $TopCategoryData=$this->Category_model->get_top_category_for_product_list();
            //pre($TopCategoryData);die;
            foreach($TopCategoryData as $k){
                $SubCateory=$this->Category_model->get_subcategory_by_category_id($k->categoryId);
                if(count($SubCateory)>0){
                    foreach($SubCateory as $kk => $vv){
                        $menuArr[$vv->categoryId]=$k->categoryName.' -> '.$vv->categoryName;
                        $ThirdCateory=$this->Category_model->get_subcategory_by_category_id($vv->categoryId);
                        if(count($ThirdCateory)>0){
                            foreach($ThirdCateory AS $k3 => $v3){
                                // now going for 4rath
                                $menuArr[$v3->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName;
                                $FourthCateory=$this->Category_model->get_subcategory_by_category_id($v3->categoryId);
                                if(count($FourthCateory)>0){ //print_r($v3);die;
                                    foreach($FourthCateory AS $k4 => $v4){
                                        $menuArr[$v4->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName.' -> '.$v4->categoryName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //pre($menuArr);die;
            $data['CategoryData']=$menuArr;
            $data['productPageType']=$productPageType;
            $data['brandArr']=array();
            if($productPageType==""){$viewPage='add_product';}else{$viewPage='add_product_'.$productPageType;}
            //$data['productPage']=$this->load->view($viewPage,$data,TRUE);
            $this->load->view($viewPage,$data);
        }

	public function add(){
            $confif=array(
                array(
                  'field'   => 'pageTypeId',
                  'label'   => 'Page type',
                  'rules'   => 'trim|required|xss_clean'
               ),
                array(
                  'field'   => 'title',
                  'label'   => 'Product Name',
                  'rules'   => 'trim|required|xss_clean'
               ),
               array(
                  'field'   => 'shortDescription',
                  'label'   => 'Product short Description',
                  'rules'   => 'trim|required|xss_clean'
               ),
               array(
                  'field'   => 'description',
                  'label'   => 'Product Description',
                  'rules'   => 'trim|required|xss_clean'
               ),
               array(
                  'field'   => 'metaTitle',
                  'label'   => 'Product Meta Title',
                  'rules'   => 'trim|required|xss_clean'
               ),
              array(
                  'field'   => 'metaDescription',
                  'label'   => 'Product Meta Description',
                  'rules'   => 'trim|required|xss_clean'
               ),
              array(
                  'field'   => 'metaKeyWord',
                  'label'   => 'Product Meta Keywords',
                  'rules'   => 'trim|required|xss_clean'
               ),
              array(
                  'field'   => 'tag',
                  'label'   => 'Product Tags',
                  'rules'   => 'trim|required|xss_clean'
               ),  
             array(
                  'field'   => 'mobileBoxContent',
                  'label'   => 'Product Tags',
                  'rules'   => 'trim|required|xss_clean'
               ),     
            );
            $type=$this->input->post('pageTypeId',TRUE);
            $categoryId=$this->input->post('categoryId',TRUE);
            $title=$this->input->post('title',TRUE);
            $shortDescription=$this->input->post('shortDescription',TRUE);
            $description=$this->input->post('description',TRUE);
            $tag=$this->input->post('tag',TRUE);
            $metaKeyWord=$this->input->post('metaKeyWord',TRUE);
            $metaTitle=$this->input->post('metaTitle',TRUE);
            $metaDescription=$this->input->post('metaDescription',TRUE);
            $mobileBoxContent=$this->input->post('mobileBoxContent',TRUE);
            $brandId=$this->input->post('brandId',TRUE);
            $noOfSims=$this->input->post('noOfSims',TRUE);
            $mobileColor=$this->input->post('mobileColor',TRUE);
            $mobileOtherFeatures=$this->input->post('mobileOtherFeatures',TRUE);
            $screenSize=$this->input->post('screenSize',TRUE);
            $displayResolution=$this->input->post('displayResolution',TRUE);
            $displayType=$this->input->post('displayType',TRUE);
            $pixelDensity=$this->input->post('pixelDensity',TRUE);
            $os=$this->input->post('os',TRUE);
            $osVersion=$this->input->post('osVersion',TRUE);
            $multiLanguages=$this->input->post('multiLanguages',TRUE);
            $mobileRearCamera=$this->input->post('mobileRearCamera',TRUE);
            $mobileFlash=$this->input->post('mobileFlash',TRUE);
            $frontCamera=$this->input->post('frontCamera',TRUE);
            $mobileOtherCameraFeatures=$this->input->post('mobileOtherCameraFeatures',TRUE);
            $mobileConnectivity=$this->input->post('mobileConnectivity',TRUE);
            
            
            
            $model=$this->input->post('model',TRUE);
            $weight=$this->input->post('weight',TRUE);
            $qty=$this->input->post('qty',TRUE);
            $minQty=$this->input->post('minQty',TRUE);
            
            $status=$this->input->post('status',TRUE);

            /*if(strlen($Title)>27){
                $this->session->set_flashdata('Message','Product name should be less than 27 Character');
                redirect(base_url().'admin/product/viewlist');
            }*/

            $dataArr=array(
            'categoryId'=>$categoryId,
            'Title'=>$Title,
            'ShortDescription'=>$ShortDescription,
            'Description'=>$Description,
            'Quantity'=>$Quantity,
            'MinQuantity'=>$MinQuantity,
            'Price'=>$Price,
            'Weight'=>$Weight,
            'MetaTitle'=>$MetaTitle,
            'MetaKeyword'=>$MetaKeyWord,
            'MetaDescription'=>$MetaDescription,
            'FreeShipping'=>$RequireShipping,
            'Model'=>$Model, //$this->my_unique_number(10),
            'Status'=>$Status,
            'TermsData'=>1
            );

            $ParrentDataArr=$this->Category_model->get_all_parrent_details($categoryId);
            //pre($ParrentDataArr);
            if($ParrentDataArr[0]->SecondParentcategoryId==""){
                $dataArr['categoryId1']=$ParrentDataArr[0]->FirstParentcategoryId;
                $dataArr['categoryId2']=$categoryId;
            }else{
                $dataArr['categoryId1']=$ParrentDataArr[0]->SecondParentcategoryId;
                $dataArr['categoryId2']=$ParrentDataArr[0]->FirstParentcategoryId;
                $dataArr['categoryId3']=$categoryId;
            }

            //echo '<pre>';print_r($dataArr);die;

            if($_FILES["ProductImage"]["name"]!=""){
                    $file=$_FILES["ProductImage"];
                    $filename=time().'.'.end(explode('.',$file["name"]));
                    //$storePath=$this->config->item('ResourcesPath');
                    //move_uploaded_file($file["tmp_name"],$storePath.'product/'.$filename);
                    $this->product_image_resize($file,$filename);
            }else{
                    //die('xxx');
                    $this->session->set_flashdata('Message','Invalid product image,Please try again.');
                    redirect(base_url().'admin/product/viewlist');
            }

            $ProductID=$this->Product_model->add($dataArr);

            $ImageDataArr=array('ProductID'=>$ProductID,'Image'=>$filename);
            $this->Product_model->add_image($ImageDataArr);

            $PriceDataArr=array('ProductID'=>$ProductID,'CountryID'=>$CountryID);
            $this->Product_model->add_country($PriceDataArr);

            $ProductTagArr=array('ProductID'=>$ProductID,'TagStr'=>$Tag);
            $this->Product_model->add_product_tag($ProductTagArr);

            $CategoryTagArr=array('categoryId'=>$ParrentDataArr[0]->FirstParentcategoryId,'TagStr'=>$Tag);
            $this->Product_model->add_category_tag($CategoryTagArr);

            $this->session->set_flashdata('Message','Product added successfully.');
            redirect(base_url().'admin/product/viewlist');
	}

	public function view_edit($ProductID=0){
		if($ProductID==0){
			$this->session->set_flashdata('Message','Invalid Course selected,Please try again.');
			redirect(base_url().'admin/product/viewlist');
		}else{
			$data=$this->_show_admin_logedin_layout();
			$data['ckeditor'] = array(
				//ID of the textarea that will be replaced
				'id' 	=> 	'Description',
				'path'	=>	$this->config->item('SiteJSURL').'ckeditor',
				'judhipath'	=>	$this->config->item('SiteJSURL'),
				//Optionnal values
				'config' => array(
					'toolbar' 	=> 	"Full", 	//Using the Full toolbar
					'width' 	=> 	"90%",	//Setting a custom width
					'height' 	=> 	'250px',	//Setting a custom height
				),
				//Replacing styles from the "Styles tool"
				'styles' => array(
					//Creating a new style named "style 1"
					'style 1' => array (
						'name' 		=> 	'Blue Title',
						'element' 	=> 	'h2',
						'styles' => array(
							'color' 	=> 	'Blue',
							'font-weight' 	=> 	'bold'
						)
					),
					//Creating a new style named "style 2"
					'style 2' => array (
						'name' 	=> 	'Red Title',
						'element' 	=> 	'h2',
						'styles' => array(
							'color' 		=> 	'Red',
							'font-weight' 		=> 	'bold',
							'text-decoration'	=> 	'underline'
						)
					)
				)
			);
			$details=$this->Product_model->details($ProductID);

			$menuArr=array();
                        $TopCategoryData=$this->Category_model->get_top_category_for_product_list();
                        //$AllButtomCategoryData=$this->Category_model->buttom_category_for_product_list();
                        foreach($TopCategoryData as $k){
                            $SubCateory=$this->Category_model->get_subcategory_by_category_id($k->categoryId);
                            if(count($SubCateory)>0){
                                foreach($SubCateory as $kk => $vv){
                                    $menuArr[$vv->categoryId]=$k->categoryName.' -> '.$vv->categoryName;
                                    $ThirdCateory=$this->Category_model->get_subcategory_by_category_id($vv->categoryId);
                                    if(count($ThirdCateory)>0){
                                        foreach($ThirdCateory AS $k3 => $v3){
                                            // now going for 4rath
                                            $menuArr[$v3->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName;
                                            $FourthCateory=$this->Category_model->get_subcategory_by_category_id($v3->categoryId);
                                            if(count($FourthCateory)>0){ //print_r($v3);die;
                                                foreach($FourthCateory AS $k4 => $v4){
                                                    $menuArr[$v4->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName.' -> '.$v4->categoryName;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        $data['CategoryData']=$menuArr;

			$data['ProductData']=$details;

			$TagData=$this->Product_model->get_tag_by_product_id($details[0]->ProductID);
			$TagStr='';
			foreach($TagData as $k){
				$TagStr .= $k->name.',';
			}
			$data['TagStr']=substr($TagStr,0,-1);
			//$data['dataArr']=$this->Course_model->get_details_by_id($CourseID);
			$this->load->view('admin/product_edit',$data);
		}
	}

	public function edit(){
		$categoryId=$this->input->post('SubcategoryId',TRUE);
		$Title=$this->input->post('Title',TRUE);
		$Description=$this->input->post('Description',TRUE);
		$ShortDescription=$this->input->post('ShortDescription',TRUE);
		$Price=$this->input->post('Price',TRUE);
		$Weight=$this->input->post('Weight',TRUE);
		$Quantity=$this->input->post('Quantity',TRUE);
		$MinQuantity=$this->input->post('MinQuantity',TRUE);
		$Tag=$this->input->post('Tag',TRUE);
		$MetaKeyWord=$this->input->post('MetaKeyword',TRUE);
		$MetaTitle=$this->input->post('MetaTitle',TRUE);
		$MetaDescription=$this->input->post('MetaDescription',TRUE);
		$Status=$this->input->post('Status',TRUE);
		$ProductID=$this->input->post('ProductID',TRUE);
		$RequireShipping=$this->input->post('RequireShipping',TRUE);
		$Model=$this->input->post('Model',TRUE);

                /*if(strlen($Title)>27){
                    $this->session->set_flashdata('Message','Product name should be less than 27 Character');
                    redirect(base_url().'admin/product/viewlist');
                }*/

		//die($ProductID);
		$dataArr=array(
		'categoryId'=>$categoryId,
		'Title'=>$Title,
		'ShortDescription'=>$ShortDescription,
		'Description'=>$Description,
		'Quantity'=>$Quantity,
		'MinQuantity'=>$MinQuantity,
		'Price'=>$Price,
		'Model'=>$Model,
		'Weight'=>$Weight,
		'MetaTitle'=>$MetaTitle,
		'MetaKeyword'=>$MetaKeyWord,
		'MetaDescription'=>$MetaDescription,
		'FreeShipping'=>$RequireShipping,
		'Status'=>$Status
		);
		//echo $ProductID.'<br>';
		//echo '<pre>';print_r($dataArr);die;
                
                $ParrentDataArr=$this->Category_model->get_all_parrent_details($categoryId);
                //pre($ParrentDataArr);
                if($ParrentDataArr[0]->SecondParentcategoryId==""){
                    $dataArr['categoryId1']=$ParrentDataArr[0]->FirstParentcategoryId;
                    $dataArr['categoryId2']=$categoryId;
                }else{
                    $dataArr['categoryId1']=$ParrentDataArr[0]->SecondParentcategoryId;
                    $dataArr['categoryId2']=$ParrentDataArr[0]->FirstParentcategoryId;
                    $dataArr['categoryId3']=$categoryId;
                }
                
                //pre($dataArr);die;

		$this->Product_model->edit($dataArr,$ProductID);
		$ProductDetails=$this->Product_model->details($ProductID);
		$oldImmage=$ProductDetails[0]->Image;
		$filename="";
		if($_FILES["ProductImage"]["name"]!=""){
			$file=$_FILES["ProductImage"];
			$filename=time().'.'.end(explode('.',$file["name"]));
			//$storePath=$this->config->item('ResourcesPath');
			$this->product_image_resize($file,$filename);
			$ImageDataArr=array('Image'=>$filename);
			/*if(move_uploaded_file($file["tmp_name"],$storePath.'product/'.$filename)){
				//echo 'file uploaded ====';
				$ImageDataArr=array('Image'=>$filename);
				if($this->Product_model->edit_product_image($ImageDataArr,$ProductID)){
					//echo 'file data updated =======';
					@unlink($storePath.'product/'.$oldImmage);
					//echo 'old file removed';die;

				}
			}*/
                        $ImageDataArr=array('Image'=>$filename);
			if($this->Product_model->edit_product_image($ImageDataArr,$ProductID)){
			//echo 'file data updated =======';
				$this->delete_product_file($oldImmage);
				//@unlink($storePath.'product/'.$oldImmage);
				//echo 'old file removed';die;
			}
		}

		$ProductTagArr=array('ProductID'=>$ProductID,'TagStr'=>$Tag);
                //echo '<pre>';print_r($ProductTagArr);die;
		$this->Product_model->edit_product_tag($ProductTagArr);
                
                $CategoryTagArr=array('categoryId'=>$ParrentDataArr[0]->FirstParentcategoryId,'TagStr'=>$Tag);
		$this->Product_model->add_category_tag($CategoryTagArr);

		$this->session->set_flashdata('Message','Product updated successfully.');
		redirect(base_url().'admin/product/viewlist');
	}
        
        function show_deal_list(){
            $data=$this->_show_admin_logedin_layout();
            $menuArr=array();
            $TopCategoryData=$this->Category_model->get_top_category_for_product_list();
            //$AllButtomCategoryData=$this->Category_model->buttom_category_for_product_list();
            foreach($TopCategoryData as $k){
                $SubCateory=$this->Category_model->get_subcategory_by_category_id($k->categoryId);
                if(count($SubCateory)>0){
                    foreach($SubCateory as $kk => $vv){
                        $menuArr[$vv->categoryId]=$k->categoryName.' -> '.$vv->categoryName;
                        $ThirdCateory=$this->Category_model->get_subcategory_by_category_id($vv->categoryId);
                        if(count($ThirdCateory)>0){
                            foreach($ThirdCateory AS $k3 => $v3){
                                // now going for 4rath
                                $menuArr[$v3->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName;
                                $FourthCateory=$this->Category_model->get_subcategory_by_category_id($v3->categoryId);
                                if(count($FourthCateory)>0){ //print_r($v3);die;
                                    foreach($FourthCateory AS $k4 => $v4){
                                        $menuArr[$v4->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName.' -> '.$v4->categoryName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $data['CategoryData']=$menuArr;
            $per_page=50;
            $PaginationConfig=array(
                'base_url'=>base_url() . "admin/product/show_deal_list",
                'total_rows'=>$this->Product_model->get_admin_total(),
                'per_page'=>$per_page,
                'num_links'=>25,
                'uri_segment'=>4
                );
            $this->_my_pagination($PaginationConfig);
            //echo $this->uri->segment(4);die;

            $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
            //echo 'KK  '.$config['per_page'];die;
            if($page==0){
                $offcet=0;
            }else{
                $offcet=$per_page*($page-1);
            }
            $data['DataArr']=$this->Product_model->get_all_admin($per_page,$offcet);


            $data["links"] = $this->pagination->create_links();
            $this->load->view('admin/manage_deal',$data);
        }
        
        function show_current_deal_list(){
            $data=$this->_show_admin_logedin_layout();
            $menuArr=array();
            $TopCategoryData=$this->Category_model->get_top_category_for_product_list();
            //$AllButtomCategoryData=$this->Category_model->buttom_category_for_product_list();
            foreach($TopCategoryData as $k){
                $SubCateory=$this->Category_model->get_subcategory_by_category_id($k->categoryId);
                if(count($SubCateory)>0){
                    foreach($SubCateory as $kk => $vv){
                        $menuArr[$vv->categoryId]=$k->categoryName.' -> '.$vv->categoryName;
                        $ThirdCateory=$this->Category_model->get_subcategory_by_category_id($vv->categoryId);
                        if(count($ThirdCateory)>0){
                            foreach($ThirdCateory AS $k3 => $v3){
                                // now going for 4rath
                                $menuArr[$v3->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName;
                                $FourthCateory=$this->Category_model->get_subcategory_by_category_id($v3->categoryId);
                                if(count($FourthCateory)>0){ //print_r($v3);die;
                                    foreach($FourthCateory AS $k4 => $v4){
                                        $menuArr[$v4->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName.' -> '.$v4->categoryName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $data['CategoryData']=$menuArr;
            $per_page=50;
            $PaginationConfig=array(
                'base_url'=>base_url() . "admin/product/show_current_deal_list",
                'total_rows'=>$this->Product_model->get_current_deal_total(),
                'per_page'=>$per_page,
                'num_links'=>25,
                'uri_segment'=>4
                );
            $this->_my_pagination($PaginationConfig);
            //echo $this->uri->segment(4);die;

            $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
            //echo 'KK  '.$config['per_page'];die;
            if($page==0){
                $offcet=0;
            }else{
                $offcet=$per_page*($page-1);
            }
            $data['DataArr']=$this->Product_model->get_all_current_deal($per_page,$offcet);


            $data["links"] = $this->pagination->create_links();
            $this->load->view('admin/manage_deal',$data);
        }

	function batchaction(){
		$batchaction_fun=  strtolower($this->input->post('batchaction_fun',TRUE));
		$batchaction_id=$this->input->post('batchaction_id',TRUE);
                //echo $batchaction_fun;die;
		$this->$batchaction_fun($batchaction_id);
	}

        function batchdownloadimages($ProductIDs){
            $this->load->dbutil();
            $this->load->library('zip');
            $rs=$this->Product_model->get_product_image_for_download($ProductIDs);
            //pre($rs);die;
            $zipData=array();
            foreach($rs AS $k){
                $zipData[$k->Image]=  file_get_contents($this->config->item('ResourcesPath').'product/original/'.$k->Image);
            }

            $this->zip->add_data($zipData);
            $this->zip->download('my_backup-'.  time().'.zip');
        }

        function batchcsvfileforimageupdate($ProductIDs){
            $this->load->dbutil();
            $this->load->helper('download');

            $sql="SELECT p.ProductID,p.Title,REPLACE(REPLACE(p.ShortDescription,'\n2',' '),'\"',' ') AS ShortDescription, 
                REPLACE(REPLACE(p.Description,'\n2',' '),'\"',' ') AS Description,p.Quantity,p.categoryId,p.MetaTitle,p.MetaKeyword,
                REPLACE(REPLACE(p.MetaDescription,'\n2',' '),'\"',' ') AS MetaDescription,p.MinQuantity,p.FreeShipping,p.Featured,p.Status,p.Price,p.Deals,p.isNew,pi.Image,pc.CountryID
                 FROM `product` AS p JOIN `product_country` AS pc ON(p.ProductID=pc.ProductID) LEFT JOIN `product_image` AS pi
                 ON(p.ProductID=pi.ProductID)  WHERE p.ProductID IN($ProductIDs)";
            $query = $this->db->query($sql);
            $delimiter = ",";
            $newline = "\r\n";

            $output= $this->dbutil->csv_from_result($query, $delimiter, $newline);
            $data = $output;//'Here is some text!';
            $name = 'all_filter_product.csv';

            force_download($name, $data);
        }

	public function batchactive($ProductIDs){
		$Action='active';
		$this->Product_model->change_status($ProductIDs ,$Action);

		$this->session->set_flashdata('Message','Product/s activated successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

	public function batchinactive($ProductIDs){
		$Action='inactive';
		$this->Product_model->change_status($ProductIDs ,$Action);

		$this->session->set_flashdata('Message','Product/s inactivated successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

	public function batchdelete($ProductIDs){
		$ProductImages=$this->Product_model->get_products_images($ProductIDs);
		$this->Product_model->delete($ProductIDs);
		foreach($ProductImages as $k){
			$this->delete_product_file($k->Image);
		}
		$this->session->set_flashdata('Message','Selected product/s deleted successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

	public function batchdeals($ProductIDs){
		$this->Product_model->deals($ProductIDs);

		$this->session->set_flashdata('Message','Product/s daily plaza deals successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

        public function batchremovedeals($ProductIDs){
		$this->Product_model->remove_deals($ProductIDs);

		$this->session->set_flashdata('Message','Product/s daily plaza remmoved deals successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

        public function batchnew($ProductIDs){
		$this->Product_model->make_new($ProductIDs);

		$this->session->set_flashdata('Message','Product/s daily plaza new successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

        public function batchremovenew($ProductIDs){
		$this->Product_model->make_old($ProductIDs);

		$this->session->set_flashdata('Message','Product/s daily plaza remove new successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

	public function batchpopular($ProductIDs){
		$this->Product_model->popular($ProductIDs);

		$this->session->set_flashdata('Message','Product/s popular flag set successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

        public function batchremovepopular($ProductIDs){
		$this->Product_model->remove_popular($ProductIDs);

		$this->session->set_flashdata('Message','Product/s popular flag set successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

	public function batchfeatured($ProductIDs){
		$this->Product_model->featured($ProductIDs);

		$this->session->set_flashdata('Message','Product/s featured successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

        public function batchremovefeatured($ProductIDs){
		$this->Product_model->remove_featured($ProductIDs);

		$this->session->set_flashdata('Message','Product/s featured removed successfully.');
		redirect(base_url().'admin/product/viewlist');
	}

	public function product_image_resize($file,$fileName,$action='uploaded'){
		/// process the image for all size. and water mark
		$PHOTOPATH=$this->config->item('ResourcesPath').'product/';
		$OriginalPath=$PHOTOPATH.'original/';
		//echo '$OriginalPath :- '.$OriginalPath.'<br>';
		$OriginalFilePath=$OriginalPath.$fileName;
		//echo '$OriginalFilePath :- '.$OriginalFilePath.'<br>';
		//echo '<pre>';print_r($file);
                if($action=='uploaded'){
                    if(!@move_uploaded_file($file["tmp_name"],$OriginalFilePath)){
                        die('not moveing the file');
                    }
                }else{
                    @copy($file,$OriginalFilePath);
                }


		//echo 'move uploaed done for original image ====<br>';
		/// ************admin***************
		$config['image_library'] = 'gd2';
		$config['source_image'] = $OriginalFilePath;
		$config['new_image'] = $PHOTOPATH. 'admin/';
		$config['width'] = 100;
		$config['height'] = 80;
		$config['maintain_ratio'] = true;
		$config['master_dim'] = 'auto';
		$config['create_thumb'] = FALSE;
		$this->image_lib->initialize($config);
		$this->load->library('image_lib', $config);
		if($this->image_lib->resize()){
			//echo '<br>thumb done for 140X100.';
		}else{
			$this->image_lib->display_errors();
		}

		$this->image_lib->clear();

		/// ************95X82*************** at index left panel
		$config['image_library'] = 'gd2';
		$config['source_image'] = $OriginalFilePath;
		$config['new_image'] = $PHOTOPATH. '95X82/';
		$config['width'] = 95;
		$config['height'] = 82;
		$config['maintain_ratio'] = true;
		$config['master_dim'] = 'auto';
		$config['create_thumb'] = FALSE;
		$this->image_lib->initialize($config);
		$this->load->library('image_lib', $config);
		if($this->image_lib->resize()){
			//echo '<br>thumb done for 95X82.';
		}else{
			$this->image_lib->display_errors();
		}

		$this->image_lib->clear();


		/// this thum crate for 139X95 ==> it is at index page listing
		$config['image_library'] = 'gd2';
		$config['source_image'] = $OriginalFilePath;
		$config['new_image'] = $PHOTOPATH . '139X95/'; //'/path/to/new_image.jpg';
		$config['width'] = 100;
		$config['height'] = 95;
		$config['maintain_ratio'] = true;
		$config['master_dim'] = 'auto';
		$config['create_thumb'] = FALSE;

		$this->image_lib->initialize($config);
		$this->load->library('image_lib', $config);

		if($this->image_lib->resize()){
			//echo '<br>thumb done for 139X95.';
		}else{
			$this->image_lib->display_errors();
		}

		$this->image_lib->clear();

		/// this thumb create for 230X180 at details page
		/// this thumb create for 350X280 at details page
		$config['image_library'] = 'gd2';
		$config['source_image'] = $OriginalFilePath;
		//$config['new_image'] = $PHOTOPATH . '230X180/'; //'/path/to/new_image.jpg';
		$config['new_image'] = $PHOTOPATH . '350X280/'; //'/path/to/new_image.jpg';
		$config['create_thumb'] = FALSE;
		$config['maintain_ratio'] = TRUE;
		//$config['width'] = 230;
		//$config['height'] = 180;

		$config['width'] = 350;
		$config['height'] = 280;

		$config['master_dim'] = 'auto';

		$this->image_lib->initialize($config);
		$this->load->library('image_lib', $config);

		if($this->image_lib->resize()){
			//echo '<br>thumb done for 230X180.';
			//echo '<br>thumb done for 350X280.';


		}else{
			$this->image_lib->display_errors();
		}

		$this->image_lib->clear();

		/// this thum crate for 95X76 at shoppign cart
		$config['image_library'] = 'gd2';
		$config['source_image'] = $OriginalFilePath;
		$config['new_image'] = $PHOTOPATH . '95X76/'; //'/path/to/new_image.jpg';
		$config['create_thumb'] = FALSE;
		$config['maintain_ratio'] = TRUE;
		$config['width'] = 95;
		$config['height'] = 76;
		$config['master_dim'] = 'auto';

		$this->image_lib->initialize($config);
		$this->load->library('image_lib', $config);

		if($this->image_lib->resize()){
			//echo '<br>thumb done for 95X76.';
		}else{
			$this->image_lib->display_errors();
		}

		$this->image_lib->clear();
		//die('end fo rproudct iamge upload');
                
                /// this thum crate for 150X150 at shoppign cart
		$config['image_library'] = 'gd2';
		$config['source_image'] = $OriginalFilePath;
		$config['new_image'] = $PHOTOPATH . '150X150/'; //'/path/to/new_image.jpg';
		$config['create_thumb'] = FALSE;
		$config['maintain_ratio'] = TRUE;
		$config['width'] = 150;
		$config['height'] = 150;
		$config['master_dim'] = 'auto';

		$this->image_lib->initialize($config);
		$this->load->library('image_lib', $config);

		if($this->image_lib->resize()){
			//echo '<br>thumb done for 150X150.';
		}else{
			$this->image_lib->display_errors();
		}

		$this->image_lib->clear();
                
                /// this thum crate for 200X200 at shoppign cart
		$config['image_library'] = 'gd2';
		$config['source_image'] = $OriginalFilePath;
		$config['new_image'] = $PHOTOPATH . '200X200/'; //'/path/to/new_image.jpg';
		$config['create_thumb'] = FALSE;
		$config['maintain_ratio'] = TRUE;
		$config['width'] = 200;
		$config['height'] = 200;
		$config['master_dim'] = 'auto';

		$this->image_lib->initialize($config);
		$this->load->library('image_lib', $config);

		if($this->image_lib->resize()){
			//echo '<br>thumb done for 200X200.';
		}else{
			$this->image_lib->display_errors();
		}

		$this->image_lib->clear();
	}

	public function delete_product_file($fileName){
		$PHOTOPATH=$this->config->item('ResourcesPath').'product/';
		$OriginalPath=$PHOTOPATH.'original/';
		@unlink($OriginalPath.$fileName);
		$AdminImage=$PHOTOPATH. 'admin/';
		@unlink($AdminImage.$fileName);
		$Image1=$PHOTOPATH. '95X76/';
		@unlink($Image1.$fileName);
		$Image2=$PHOTOPATH. '95X82/';
		@unlink($Image2.$fileName);
		$Image3=$PHOTOPATH. '139X95/';
		@unlink($Image3.$fileName);
		$Image4=$PHOTOPATH. '95X76/';
		@unlink($Image4.$fileName);
		//$Image5=$PHOTOPATH. '230X180/';
		$Image5=$PHOTOPATH. '350X280/';
		@unlink($Image5.$fileName);
                $Image5=$PHOTOPATH. '150X150/';
		@unlink($Image5.$fileName);
                $Image5=$PHOTOPATH. '200X200/';
		@unlink($Image5.$fileName);

		return TRUE;
	}

	public function copy(){
		//print_r($_POST);die;
		$CountryID=$this->input->post('CountryID',TRUE);
		$IND=$this->input->post('99',TRUE);
		$USA=$this->input->post('1',TRUE);
		$OTH=$this->input->post('240',TRUE);
		$ProductID=$this->input->post('ProductID',TRUE);
		$CountryPriceArr=array('99'=>'IND','1'=>'USA','240'=>'OTH');
		//print_r($CountryID);die;
		foreach($CountryID AS $k => $v){

			//echo $Price[$k].''
			if($$CountryPriceArr[$v]==""){
				$this->session->set_flashdata('Message','Invalid price provided for copy the product.');
				redirect(base_url().'admin/product/viewlist');
			}
		}
		$ProductDetailsArr=$this->Product_model->details($ProductID);

		$OldImage=$ProductDetailsArr[0]->Image;

		$dataArr=array(
			'categoryId'=>$ProductDetailsArr[0]->categoryId,
			'Title'=>$ProductDetailsArr[0]->Title,
			'ShortDescription'=>$ProductDetailsArr[0]->ShortDescription,
			'Description'=>$ProductDetailsArr[0]->Description,
			'Quantity'=>$ProductDetailsArr[0]->Quantity,
			'MinQuantity'=>$ProductDetailsArr[0]->MinQuantity,
			//'Price'=>$ProductDetailsArr[0]->Price,
			'Weight'=>$ProductDetailsArr[0]->Weight,
			'MetaTitle'=>$ProductDetailsArr[0]->MetaTitle,
			'MetaKeyword'=>$ProductDetailsArr[0]->MetaKeyword,
			'MetaDescription'=>$ProductDetailsArr[0]->MetaDescription,
			'FreeShipping'=>$ProductDetailsArr[0]->FreeShipping,
			'Status'=>$ProductDetailsArr[0]->Status,
                        'TermsData'=>1,
                        'categoryId1'=>$ProductDetailsArr[0]->categoryId1,
                        'categoryId2'=>$ProductDetailsArr[0]->categoryId2,
                        'categoryId3'=>$ProductDetailsArr[0]->categoryId3,
			);
                
		//$this->Product_model->copy_tag($ProductID,2);die;
		//print_r($dataArr);die;
                $oldModel=$ProductDetailsArr[0]->Model;
                $ModelDynamicChar=array(0=>'A','1'=>'B');
		foreach($CountryID AS $k => $v){

                        //echo $k;die;
			//if($v!=240){
				//echo 'zzz<br>';die;
				$filename=time().base64_encode(rand(1,9)).'.'.end(explode('.',$OldImage));
				$this->copy_product_image($OldImage,$filename);

				$dataArr['Price']=$$CountryPriceArr[$v];  //$Price[$k];
				$dataArr['Model']=$oldModel.$ModelDynamicChar[$k];
                                //echo '<pre>';print_r($dataArr);die;
				$NewCopyProductID=$this->Product_model->add($dataArr);

				$ImageDataArr=array('ProductID'=>$NewCopyProductID,'Image'=>$filename);
				$this->Product_model->add_image($ImageDataArr);

				$PriceDataArr=array('ProductID'=>$NewCopyProductID,'CountryID'=>$v);
				$this->Product_model->add_country($PriceDataArr);

				$this->Product_model->copy_tag($ProductID,$NewCopyProductID);
				//echo 'Product added for country $v: '.$v.'<br>';
				//$ProductTagArr=array('ProductID'=>$NewCopyProductID,'TagStr'=>$Tag);
				//$this->Product_model->add_product_tag($ProductTagArr);
			//}
			/*else if($v==240){
				//echo 'zzz XX<br>';die;
				$this->load->model('Country');
				$CountryData=$this->Country->get_240();
				foreach($CountryData AS $key1){
					$filename="";
					$NewCopyProductID=0;
					$filename=time().base64_encode(rand(1,9)).'.'.end(explode('.',$OldImage));
					$this->copy_product_image($OldImage,$filename);

					$dataArr['Price']=$Price[$k];
					$NewCopyProductID=$this->Product_model->add($dataArr);

					$ImageDataArr=array('ProductID'=>$NewCopyProductID,'Image'=>$filename);
					$this->Product_model->add_image($ImageDataArr);

					$PriceDataArr=array('ProductID'=>$NewCopyProductID,'CountryID'=>$key1->CountryID);
					$this->Product_model->add_country($PriceDataArr);

					$this->Product_model->copy_tag($ProductID,$NewCopyProductID);
					echo 'Product added for country $k->CountryID: '.$key1->CountryID.'<br>';
				}
			}*/
		}
		$this->session->set_flashdata('Message','Product Copyied to selected countries successfully !!.');
		redirect(base_url().'admin/product/viewlist');
	}

	public function copy_product_image($oldFileName,$fileName){
		$PHOTOPATH=$this->config->item('ResourcesPath').'product/';
		$OriginalPath=$PHOTOPATH.'original/';
		//echo '$OriginalPath :- '.$OriginalPath.'<br>';
		$OldOriginal=$OriginalPath.$oldFileName;
		$NewOriginal=$OriginalPath.$fileName;
		@copy($OldOriginal,$NewOriginal);

		//admin file
		$OldAdmin=$PHOTOPATH. 'admin/'.$oldFileName;
		$NewAdmin=$PHOTOPATH. 'admin/'.$fileName;
		@copy($OldAdmin,$NewAdmin);

		//95X82 file
		$Old95X82=$PHOTOPATH. '95X82/'.$oldFileName;
		$New95X82=$PHOTOPATH. '95X82/'.$fileName;
		@copy($Old95X82,$New95X82);

		//139X95 file
		$Old139X95=$PHOTOPATH. '139X95/'.$oldFileName;
		$New139X95=$PHOTOPATH. '139X95/'.$fileName;
		@copy($Old139X95,$New139X95);

		//230X180 file
		//$Old230X180=$PHOTOPATH. '230X180/'.$oldFileName;
		//$New230X180=$PHOTOPATH. '230X180/'.$fileName;
		//@copy($Old230X180,$New230X180);

		$Old350X280=$PHOTOPATH. '350X280/'.$oldFileName;
		$New350X280=$PHOTOPATH. '350X280/'.$fileName;
		@copy($Old350X280,$New350X280);

		//95X76 file
		$Old95X76=$PHOTOPATH. '95X76/'.$oldFileName;
		$New95X76=$PHOTOPATH. '95X76/'.$fileName;
		@copy($Old95X76,$New95X76);
                
                //150X150 file
		$Old150X150=$PHOTOPATH. '150X150/'.$oldFileName;
		$New150X150=$PHOTOPATH. '150X150/'.$fileName;
		@copy($Old150X150,$New150X150);
                
                //200X200 file
		$Old200X200=$PHOTOPATH. '200X200/'.$oldFileName;
		$New200X200=$PHOTOPATH. '200X200/'.$fileName;
		@copy($Old200X200,$New200X200);

	}

        public function search_filter(){
            $Title              =  $this->input->get_post('SearchFilterTitle',TRUE);
            $Model              =  $this->input->get_post('SearchFilterCode',TRUE);
            $Status             =  $this->input->get_post('SearchFilterStatus',TRUE);
            $Featured           =  $this->input->get_post('SearchFilterFeatured',TRUE);
            $Popular           =  $this->input->get_post('SearchFilterPopular',TRUE);
            $TopcategoryId      =  $this->input->get_post('SearchFilterTopCategory',TRUE);
            $categoryId         =  $this->input->get_post('SearchFilterSearchcategoryId',TRUE);
            $Region             =  $this->input->get_post('SearchFilterRegion',TRUE);

            $data=$this->_show_admin_logedin_layout();
            $data['ckeditor'] = array(
                    //ID of the textarea that will be replaced
                    'id' 	=> 	'Description',
                    'path'	=>	$this->config->item('SiteJSURL').'ckeditor',
                    'judhipath'	=>	$this->config->item('SiteJSURL'),
                    //Optionnal values
                    'config' => array(
                            'toolbar' 	=> 	"Full", 	//Using the Full toolbar
                            'width' 	=> 	"90%",	//Setting a custom width
                            'height' 	=> 	'250px',	//Setting a custom height
                    ),
                    //Replacing styles from the "Styles tool"
                    'styles' => array(
                            //Creating a new style named "style 1"
                            'style 1' => array (
                                    'name' 		=> 	'Blue Title',
                                    'element' 	=> 	'h2',
                                    'styles' => array(
                                            'color' 	=> 	'Blue',
                                            'font-weight' 	=> 	'bold'
                                    )
                            ),
                            //Creating a new style named "style 2"
                            'style 2' => array (
                                    'name' 	=> 	'Red Title',
                                    'element' 	=> 	'h2',
                                    'styles' => array(
                                            'color' 		=> 	'Red',
                                            'font-weight' 		=> 	'bold',
                                            'text-decoration'	=> 	'underline'
                                    )
                            )
                    )
            );
            $menuArr=array();
            $TopCategoryData=$this->Category_model->get_top_category_for_product_list();
            //$AllButtomCategoryData=$this->Category_model->buttom_category_for_product_list();
            foreach($TopCategoryData as $k){
                $SubCateory=$this->Category_model->get_subcategory_by_category_id($k->categoryId);
                if(count($SubCateory)>0){
                    foreach($SubCateory as $kk => $vv){
                        $menuArr[$vv->categoryId]=$k->categoryName.' -> '.$vv->categoryName;
                        $ThirdCateory=$this->Category_model->get_subcategory_by_category_id($vv->categoryId);
                        if(count($ThirdCateory)>0){
                            foreach($ThirdCateory AS $k3 => $v3){
                                // now going for 4rath
                                $menuArr[$v3->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName;
                                $FourthCateory=$this->Category_model->get_subcategory_by_category_id($v3->categoryId);
                                if(count($FourthCateory)>0){ //print_r($v3);die;
                                    foreach($FourthCateory AS $k4 => $v4){
                                        $menuArr[$v4->categoryId]=$k->categoryName.' -> '.$vv->categoryName.' -> '.$v3->categoryName.' -> '.$v4->categoryName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $data['CategoryData']=$menuArr;
            $OldProductTags=$this->Product_model->get_all_tag();
            $OldProductTagsStr='';
            foreach($OldProductTags AS $k){
                if($OldProductTagsStr==''){
                    $OldProductTagsStr="'$k->name',";
                }else{
                    $OldProductTagsStr=$OldProductTagsStr."'$k->name',";          //'"'.$k->name.'",';
                    //echo $k->name.' == '.$OldProductTagsStr.'<br>';
                }
            }
            //echo $OldProductTagsStr;die;
            if(substr($OldProductTagsStr,-1)==','){
                $OldProductTagsStr=  substr($OldProductTagsStr, 0,-1);
            }
            $data['OldProductTagsStr']=$OldProductTagsStr;

            /*$per_page=20;
            $PaginationConfig=array(
                'base_url'=>base_url() . "admin/product/search_filter",
                'total_rows'=>$this->Product_model->get_admin_total(),
                'per_page'=>$per_page,
                'num_links'=>15,
                'uri_segment'=>4
                );
            $this->_my_pagination($PaginationConfig);
            //echo $this->uri->segment(4);die;
             *
             */

            $page = ($this->uri->segment(4)) ? $this->uri->segment(4) : 0;
            //echo 'KK  '.$config['per_page'];die;
            $data['DataArr']=$this->Product_model->get_all_admin();


            $data["links"] = $this->pagination->create_links();
            $this->load->view('admin/product_list',$data);
        }

        public function tag_list($categoryId=0){
            $data=$this->_show_admin_logedin_layout();
            $data['TopCategoryDataArr']=$this->Category_model->get_top_category();
            if($categoryId==0){
                $data['DataArr']=$this->Product_model->get_all_tag();
            }else{
                $data['DataArr']=$this->Category_model->all_tag_data_by_category($categoryId);
            }
            $this->load->view('admin/tag_list',$data);
        }

        function tag_batchaction(){
            //pre($_POST);die;
		$batchaction_fun=$this->input->post('batchaction_fun',TRUE);
		$batchaction_id=$this->input->post('batchaction_id',TRUE);
		$this->$batchaction_fun($batchaction_id);
	}

        function batchaddlanding($TagIDs){
            $this->Product_model->update_tag_state($TagIDs ,array('Landing'=>1));

            $this->session->set_flashdata('Message','Tag/s set for landing page successfully.');
            redirect(base_url().'admin/product/tag_list');
        }

        function batchaddhome($TagIDs){
            $this->Product_model->update_tag_state($TagIDs ,array('Home'=>1));

            $this->session->set_flashdata('Message','Tag/s set for home page successfully.');
            redirect(base_url().'admin/product/tag_list');
        }

        function batchremovelanding($TagIDs){
            $this->Product_model->update_tag_state($TagIDs ,array('Landing'=>0));

            $this->session->set_flashdata('Message','Tag/s remove from landing page successfully.');
            redirect(base_url().'admin/product/tag_list');
        }

        function batchremovehome($TagIDs){
            $this->Product_model->update_tag_state($TagIDs ,array('Home'=>0));

            $this->session->set_flashdata('Message','Tag/s remove from home page successfully.');
            redirect(base_url().'admin/product/tag_list');
        }
        

        function csv_import_file_from_db(){
            $mimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv','text/octect-stream','"application/x-download"','"text/x-comma-separated-values"','text/x-csv');
            //echo $_FILES['product_import_file']['type'];die;
            if(in_array($_FILES['product_import_file']['type'],$mimes)){
                $field_string='Title,ShortDescription,Description,Weight,Quantity,categoryId,MetaTitle,MetaKeyword,MetaDescription,MinQuantity,FreeShipping,Featured,Status,Price,Deals,Model,isNew,ProductImage,RegionID,TagStr';
                $field_string_array=  explode(',', $field_string);
                //$file = $_FILES['product_import_file']['tmp_name'];
                $file = $_FILES['product_import_file']['tmp_name'];
                //$table='product';
                //csv_import_file_from_db($file,$field_string,$table);
                $data=array();
                //$handle = fopen($file,"r");

                $j=0;
                $productDataArr=array();
                //loop through the csv file and insert into database
                $row = 1;
                if (($handle = fopen($file, "r")) !== FALSE) {
                    while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
                        if($row==1){
                            $row++;
                            continue;
                        }
                        $num = count($data);
                        //echo "<p> $num fields in line $row: <br /></p>\n";
                        //echo '<pre>';print_r($field_string_array);die;
                        //echo '<pre>';print_r($data);die;
                        $value_string='';
                        $tempDataArr=array();
                        $newFileName='';
                        $Tag='';
                        for ($c=0; $c < $num; $c++) {
                            //echo $data[$c] . "<br />\n";
                            if($field_string_array[$c]=='ProductImage'){
                                if($data[$c]!=""){
                                    $image_file_name=$data[$c];
                                    $FullFileName=  $this->config->item('ResourcesPath').'product/csv_import_add/'.$image_file_name;
                                    if(file_exists($FullFileName)){
                                        $newFileName=time().uniqid().'.'.end(explode('.',$image_file_name));
                                        $this->product_image_resize($FullFileName,$newFileName,'import');
                                    }else{
                                        //echo $FullFileName.' => not exists.'."<br>";
                                    }
                                    //$tempDataArr[$field_string_array[$c]]=$newFileName;
                                }else{
                                    //echo '$data[$c] => '." empty.<br>";
                                }
                            }else if($field_string_array[$c]=='RegionID'){
                                $CountryID=$data[$c];
                            }else if($field_string_array[$c]=='TagStr'){
                                $Tag=$data[$c];
                                //echo '$Tag = '.$Tag;die;
                            }else{
                                $tempDataArr[$field_string_array[$c]]=$data[$c];
                            }
                        }
                        
                       //echo '<pre>';print_r($tempDataArr);echo '$newFileName = '.$newFileName.'  $CountryID = '.$CountryID.'  = $Tag = '.$Tag.' <br>'; die;
                        if(!empty($tempDataArr) && $newFileName!=""){
                            //echo "<br>".'comming foor new product ading '."<br>";
                            
                            $ParrentDataArr=$this->Category_model->get_all_parrent_details($tempDataArr['categoryId']);
                            
                            if($ParrentDataArr[0]->SecondParentcategoryId==""){
                                $dataArr['categoryId1']=$ParrentDataArr[0]->FirstParentcategoryId;
                                $dataArr['categoryId2']=$tempDataArr['categoryId'];
                            }else{
                                $dataArr['categoryId1']=$ParrentDataArr[0]->SecondParentcategoryId;
                                $dataArr['categoryId2']=$ParrentDataArr[0]->FirstParentcategoryId;
                                $dataArr['categoryId3']=$tempDataArr['categoryId'];
                            }
                            
                            $tempDataArr['TermsData']=1;
                            $ProductID=$this->Product_model->add($tempDataArr);

                            $ImageDataArr=array('ProductID'=>$ProductID,'Image'=>$newFileName);
                            $this->Product_model->add_image($ImageDataArr);

                            $PriceDataArr=array('ProductID'=>$ProductID,'CountryID'=>$CountryID);
                            $this->Product_model->add_country($PriceDataArr);

                            if($Tag!=""){
                                $ProductTagArr=array('ProductID'=>$ProductID,'TagStr'=>$Tag);
                                $this->Product_model->add_product_tag($ProductTagArr);
                                
                                $CategoryTagArr=array('categoryId'=>$ParrentDataArr[0]->FirstParentcategoryId,'TagStr'=>$Tag);
                                $this->Product_model->add_category_tag($CategoryTagArr);
                            }

                        }
                    }
                    fclose($handle);
                }
                //die('test');
                $this->session->set_flashdata('Message','All products in the csv file are uploaded successfully.');
                redirect(base_url().'admin/product/viewlist');
            }

        }

        function csv_import_file_from_db_update(){
            $mimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv','text/octect-stream','"application/x-download"','"text/x-comma-separated-values"','text/x-csv');
            //echo '<pre>';print_r($_FILES);die;
            //echo $_FILES['product_import_file']['type'];die;
            if(in_array($_FILES['product_import_file']['type'],$mimes)){
                $field_string='ProductID,Title,ShortDescription,Description,Quantity,categoryId,MetaTitle,MetaKeyword,MetaDescription,MinQuantity,FreeShipping,Featured,Status,Price,Deals,isNew,Image,CountryID';
                $field_string_array=  explode(',', $field_string);
                //$file = $_FILES['product_import_file']['tmp_name'];
                $file = $_FILES['product_import_file']['tmp_name'];
                //$table='product';
                //csv_import_file_from_db($file,$field_string,$table);
                $data=array();
                //$handle = fopen($file,"r");

                $j=0;
                $productDataArr=array();
                //loop through the csv file and insert into database
                $row = 1;
                if (($handle = fopen($file, "r")) !== FALSE) {
                    while (($data = fgetcsv($handle, 10000, ",")) !== FALSE) {
                        if($row==1){
                            $row++;
                            continue;
                        }
                        $num = count($data);
                        //echo '$num = '.$num.' <br>';
                        /*if($num>18){
                            echo '<pre>';print_r($field_string_array);//die;
                            echo '<pre>';print_r($data);die; 
                        }*/
                        //echo "<p> $num fields in line $row: <br /></p>\n";
                        //echo '<pre>';print_r($field_string_array);die;
                        //echo '<pre>';print_r($data);die; 
                        $value_string='';
                        $tempDataArr=array();
                        $newFileName='';
                        $Tag='';
                        $ProductID=0;
                        for ($c=0; $c < $num; $c++) {
                            /*if(!key_exists($c, $data)){
                                echo $c.'<br>';
                                pre($data);
                                pre($field_string_array); 
                                die;
                            }*/
                            if($field_string_array[$c]=='Image'){
                                if($data[$c]!=""){
                                    $image_file_name=$data[$c];
                                    $FullFileName=  $this->config->item('ResourcesPath').'product/csv_import_add/'.$image_file_name;
                                    if(file_exists($FullFileName)){
                                        $newFileName=time().uniqid().'.'.end(explode('.',$image_file_name));
                                        $this->product_image_resize($FullFileName,$newFileName,'import');
                                    }else{
                                        //echo $FullFileName.' => not exists.'."<br>";
                                    }
                                    //$tempDataArr[$field_string_array[$c]]=$newFileName;
                                }else{
                                    //echo '$data[$c] => '." empty.<br>";
                                }
                            }else if($field_string_array[$c]=='CountryID'){
                                $CountryID=$data[$c];
                            //}else if($field_string_array[$c]=='TagStr'){
                                //$Tag=$data[$c];
                            }else if($field_string_array[$c]=='ProductID'){
                                $ProductID=$data[$c];
                            }else{
                                $tempDataArr[$field_string_array[$c]]=$data[$c];
                            }
                        }
                        //echo '<pre>';print_r($tempDataArr);
                        //echo '$newFileName = '.$newFileName.'  $CountryID = '.$CountryID.'  = $Tag = '.$Tag.' <br>'; //die;
                        if($ProductID>0){
                            $ParrentDataArr=$this->Category_model->get_all_parrent_details($tempDataArr['categoryId']);
                            if($ParrentDataArr[0]->SecondParentcategoryId==""){
                                $dataArr['categoryId1']=$ParrentDataArr[0]->FirstParentcategoryId;
                                $dataArr['categoryId2']=$tempDataArr['categoryId'];;
                            }else{
                                $dataArr['categoryId1']=$ParrentDataArr[0]->SecondParentcategoryId;
                                $dataArr['categoryId2']=$ParrentDataArr[0]->FirstParentcategoryId;
                                $dataArr['categoryId3']=$tempDataArr['categoryId'];;
                            }
                            
                            $tempDataArr['TermsData']=1;
                            $this->Product_model->edit($tempDataArr,$ProductID);

                            if($newFileName!=""){
                                $ImageDataArr=array('Image'=>$newFileName);
                                $this->Product_model->edit_product_image($ImageDataArr,$ProductID);
                            }

                            /*if($Tag!=""){
                                $ProductTagArr=array('ProductID'=>$ProductID,'TagStr'=>$Tag);
                                $this->Product_model->add_product_tag($ProductTagArr);
                            }*/

                        }
                    }
                    fclose($handle);
                }
                die('test');
                $this->session->set_flashdata('Message','All products in the csv file are uploaded successfully.');
                redirect(base_url().'admin/product/viewlist');
            }

        }

        function image_resize_for_web_mobile($new_width_height_size=""){
            if($new_width_height_size==""){
                return FALSE;
            }
            $new_width_height_size_arr=  explode("X", $new_width_height_size);
            @set_time_limit(1500);
            //echo 'kkk';die;
            /// process the image for all size. and water mark
		$PHOTOPATH=$this->config->item('ResourcesPath').'product/';
		$OriginalPath=$PHOTOPATH.'original/';
                $AllOriginalImages=@scandir($OriginalPath,1);
                if(count($AllOriginalImages)>2){
                    $tempNo=count($AllOriginalImages)-2;
                    echo '$tempNo => '.$tempNo.' total => '.count($AllOriginalImages).'<br>';
                    for($i=0;$i<$tempNo;$i++){
                        $OriginalFilePath=$OriginalPath.$AllOriginalImages[$i];
                        echo '$OriginalFilePath = > '.$OriginalFilePath.'<br>';
                        if(file_exists($OriginalFilePath)){
                            $MobileCategoyPhotoPath=$PHOTOPATH. $new_width_height_size.'/';
                            $MobileCategoyImage=$MobileCategoyPhotoPath.$AllOriginalImages[$i];
                            if(!file_exists($MobileCategoyImage)){
                                echo $AllOriginalImages[$i].' for '.$new_width_height_size.' <br>';
                                $config['image_library'] = 'gd2';
                                $config['source_image'] = $OriginalFilePath;
                                $config['new_image'] = $MobileCategoyPhotoPath;
                                $config['width'] = $new_width_height_size_arr[0];
                                $config['height'] =$new_width_height_size_arr[1];
                                $config['maintain_ratio'] = true;
                                $config['master_dim'] = 'auto';
                                $config['create_thumb'] = FALSE;
                                $this->image_lib->initialize($config);
                                $this->load->library('image_lib', $config);
                                if($this->image_lib->resize()){
                                        //echo '<br>thumb done for 140X100.';
                                }else{
                                        $this->image_lib->display_errors();
                                }
                            }else{
                                echo $AllOriginalImages[$i].' for '.$new_width_height_size.' exists <br>';
                            }

                            $this->image_lib->clear();

                            /*$MobileBigPhotoPath=$PHOTOPATH. '300X350/';
                            $MobileBigImage=$MobileBigPhotoPath.$AllOriginalImages[$i];
                            if(!file_exists($MobileBigImage)){
                                echo $AllOriginalImages[$i].' for 300X350 <br>';
                                $config['image_library'] = 'gd2';
                                $config['source_image'] = $OriginalFilePath;
                                $config['new_image'] = $MobileBigPhotoPath;
                                $config['width'] = 300;
                                $config['height'] = 350;
                                $config['maintain_ratio'] = true;
                                $config['master_dim'] = 'auto';
                                $config['create_thumb'] = FALSE;
                                $this->image_lib->initialize($config);
                                $this->load->library('image_lib', $config);
                                if($this->image_lib->resize()){
                                        //echo '<br>thumb done for 140X100.';
                                }else{
                                        $this->image_lib->display_errors();
                                }
                            }else{
                                echo $AllOriginalImages[$i].' for 300X350 exists <br>';
                            }
                            $this->image_lib->clear();*/
                        }else{
                            echo '$OriginalFilePath  not exists = > <br>';
                        }

                    }
                }
        }
    
    function set_deal(){
        $ProductID=$this->input->post('ProductID',TRUE);
        $DealPrice=$this->input->post('DealPrice',TRUE);
        if($this->Product_model->edit(array('DealPrice'=>$DealPrice,'Deals'=>1),$ProductID)==TRUE){
            $ProductDetails=$this->Product_model->details($ProductID);
            $TopcategoryId=$this->get_top_category_by_product_id($ProductDetails[0]->categoryId);
            if($this->Product_model->is_exist_deal_for_category($TopcategoryId,$ProductDetails[0]->CountryID,$ProductID)){
                $this->Product_model->edit_deal($ProductID,$TopcategoryId,$ProductDetails[0]->CountryID);
            }else{
                $this->Product_model->set_deal(array('categoryId'=>$TopcategoryId,'ProductID'=>$ProductID,'RegionID'=>$ProductDetails[0]->CountryID));
            }
            echo 'ok';
        }else{
            echo 'not';
        }
    }
    
    function remove_deal(){
        $ProductID=$this->input->post('ProductID',TRUE);
        if($this->Product_model->edit(array('DealPrice'=>'','Deals'=>0),$ProductID)==TRUE){
            $this->Product_model->remove_deal($ProductID);
            echo 'ok';
        }else{
            echo 'not';
        }
    }
    
    function get_top_category_by_product_id($categoryId){
        $Details=$this->Category_model->get_details_by_id($categoryId);
        if($Details[0]->ParrentcategoryId==0){
            return $categoryId;
        }else{
            return $this->get_top_category_by_product_id($Details[0]->ParrentcategoryId);
        }
    }
    
    function update_new_category(){
        @set_time_limit(2500);
        $rs=$this->db->query("SELECT * FROM product")->result();
        foreach($rs AS $k){
            //pre($k->categoryId);die;
            $CategoryArr=  array_reverse($this->get_category_arr($k->categoryId));
            $ColArr=array();
            foreach($CategoryArr as $p => $pV){
                $nt=$p+1;
                $ColArr['categoryId'.$nt]=$pV;
            }
            $this->Product_model->edit($ColArr,$k->ProductID);
        }
    }
    
    function get_category_arr($categoryId,$CategoryArr=array()){
        if(empty($CategoryArr)){
            $CategoryArr[]=$categoryId;
            $Details=$this->Category_model->get_details_by_id($categoryId);
            $CategoryArr[]=$Details[0]->ParrentcategoryId;
            return $this->get_category_arr($Details[0]->ParrentcategoryId,$CategoryArr);
        }else{
            $Details=$this->Category_model->get_details_by_id($categoryId);
            if($Details[0]->ParrentcategoryId==0){
                return $CategoryArr;    
            }else{
                $CategoryArr[]=$Details[0]->ParrentcategoryId;
                return $this->get_category_arr($Details[0]->ParrentcategoryId,$CategoryArr);
            }
        }
    }
    
    function update_category_tag(){
        $dataArr=array();
        $rs=$this->db->query("SELECT p.ProductID,p.categoryId1,pt.TagID FROM product AS p JOIN product_tag AS pt ON(p.ProductID=pt.ProductID)")->result();
        //pre($rs);die;
        foreach($rs As $k){
            //pre('--------');
            //pre($dataArr);
            if($this->checkCategoryExists($dataArr, $k->categoryId1,$k->TagID)==FALSE){
                $rs=$this->db->query("SELECT * FROM category_tag WHERE categoryId='".$k->categoryId1."' AND TagID='".$k->TagID."'")->result();
                if(empty($rs))
                    $dataArr[]=array('categoryId'=>$k->categoryId1,'TagID'=>$k->TagID);
            }
        }
        $this->db->insert_batch('category_tag',$dataArr);
    }
    
    function checkCategoryExists($dataArr,$categoryId,$TagID){
        //pre('+++++++++++');
        //pre($dataArr);
        //pre('==========');
        //pre($categoryId);
        if(empty($dataArr)) return FALSE;
        //pre('***********');
        foreach($dataArr As $k){
            if($k['categoryId']==$categoryId && $k['TagID']==$TagID){
                return TRUE;
            }
        }
        return FALSE;
    }
    
    function update_category_tags_date(){
        $rs=$this->db->from('category_tag')->get()->result();
        foreach($rs As $k){
            $this->db->where('CategoryTagID',$k->CategoryTagID);
            $this->db->update('category_tag',array('TagDate'=>time()));
            //echo $this->db->last_query();die;
            //$this->db->query("UPDATE `category_tag` SET TagDate='".time()."' WHERE ``=".$k->CategoryTagID);
        }
    }
    
    
    function batchremovetags($TagIDArr){
        $categoryId=$this->input->post('category_id',TRUE);
        if($categoryId!==""){
            $this->db->where_in('TagID',explode(',',$TagIDArr));
            $this->db->where('categoryId',$categoryId);
            $this->db->delete('category_tag'); 
        }else{
            $this->db->where_in('TagID',explode(',',$TagIDArr));
            $this->db->delete('category_tag'); 
        }
        
        $this->session->set_flashdata('Message','Tag/s removed successfully.');
        redirect(base_url().'admin/product/tag_list/'.$categoryId);
    }
    
    function batchsetposition($TagIDs){
        //pre(explode(',',$TagIDs));
        $categoryId=$this->input->post('category_id',TRUE);
        $this->db->where_in('TagID',explode(',',$TagIDs));
        $this->db->where('categoryId',$categoryId);
        $this->db->update('category_tag',array('TagDate'=>time()));
        //echo $this->db->last_query();die;
        redirect(base_url().'admin/product/tag_list/'.$categoryId);
    }
    
}
?>