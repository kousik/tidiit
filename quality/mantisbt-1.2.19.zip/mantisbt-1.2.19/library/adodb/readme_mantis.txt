Description of Adodb import into mantis.

See ../readme.libs for summary of all libraries

Removed:
	contrib/
	cute_icons_for_site/
	docs/
	pear/
	server.php
	tests/

Added:
	readme_mantis.txt - this file ;-)
	index.html - prevent directory browsing on misconfigured servers

Changes:
	adodb.inc.php
	adodb-datadict.inc.php
	datadict\datadict-mssql.inc.php
	datadict\datadict-mssqlnative.inc.php
	datadict\datadict-postgres.inc.php
	odbc/postgres/mssql/db2 drivers/datadict
	

